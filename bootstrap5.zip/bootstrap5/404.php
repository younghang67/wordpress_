<?php get_header(); ?>
<div class="404-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-md-10">
                <img  class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/404.webp" alt="404-page">
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>