<?php if (is_active_sidebar('default_sidebar')): ?>
    <?php dynamic_sidebar('default_sidebar'); ?>
<?php endif; ?>