(function ($) {

    $(document).ready(function () {
        $('.default_sidebar > ul').addClass('list-group list-group-flush');
        $('.default_sidebar > ul > li').addClass('list-group-item cus-li');
        $('.default_sidebar > ul > li > a').addClass('text-decoration-none text-dark');

        // footer widget
        $('.footer_widget > ul').addClass('list-unstyled ');
        $('.footer_widget > ul > li > a').addClass('text-decoration-none text-white');

        // front page image
        $('.main-header img').addClass('rounded');

        //pre used in the sampal page code
        $('.wp-block-group__inner-container').addClass('pre');

        $('#comments #reply-title').addClass('fs-4 text-dark font-100');
        $('#commentform > p').addClass('m-0');
        $('#commentform #comment, #commentform #author, #commentform #email , #commentform #url').addClass('form-control form-control-sm mb-2');
        $('#commentform #submit').addClass('btn btn-success btn-sm');

        $('.comment-form-cookies-consent').addClass('mb-2');
    })

})(jQuery);